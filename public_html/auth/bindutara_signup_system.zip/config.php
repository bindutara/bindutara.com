<?php
// SMTP Config (Gmail)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 465);
define('SMTP_USER', 'bindutarapvtltd@gmail.com');
define('SMTP_PASS', 'wdhp tyqt waod ciyg');

// Zoho CRM Config
define('ZOHO_CLIENT_ID', '1000.GBHHEA74RT561MED1N7CC5T8AD3QXR');
define('ZOHO_CLIENT_SECRET', '16281eb8b6246979fde55c414db366eab6ddd2758a');
define('ZOHO_REFRESH_TOKEN', 'PUT_YOUR_REFRESH_TOKEN_HERE');
?>